import styles from './Footer.module.css'

function Footer(){
    return(
        <footer className={styles.footer}>
          FEITO COM ♡ por DANIEL AUGUSTO E JÚLIA BISPO
        </footer>
    )
}
export default Footer;