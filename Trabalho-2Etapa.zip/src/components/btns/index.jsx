import styles from './button.module.css'

function Footer(){
    return(
      
      <button className={styles.btn}>
          INICIAR
        </button>
    )
}
export default Footer;